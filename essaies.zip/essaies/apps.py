from django.apps import AppConfig


class EssaiesConfig(AppConfig):
    name = 'essaies'
